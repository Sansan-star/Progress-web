const form = document.querySelector('form');
const usernameInput = document.querySelector('#username'); // Pastikan id sesuai

// Hindari submit default
form.addEventListener('submit', (event) => {
  event.preventDefault();
  console.log('Form submitted'); // Tambahkan log atau aksi jika perlu
});

// Fungsi untuk menangani validasi
const validateUsername = (event) => {
  const input = event.target;
  input.setCustomValidity(''); // Reset pesan custom

  if (input.validity.valueMissing) {
    input.setCustomValidity('Wajib diisi.');
  } else if (input.validity.tooShort) {
    input.setCustomValidity('Minimal panjang adalah enam karakter.');
  } else if (input.validity.patternMismatch) {
    input.setCustomValidity(
      'Tidak boleh diawali dengan simbol, mengandung white space atau spasi, dan mengandung karakter spesial seperti dolar ($).'
    );
  }

  const errorMessage = input.validationMessage;
  const validationEl = document.getElementById(
    input.getAttribute('aria-describedby')
  );

  // Update pesan validasi pada elemen yang terhubung
  if (validationEl) {
    validationEl.innerText = errorMessage || '';
  }
};

// Tambahkan event listener
usernameInput.addEventListener('input', validateUsername);
usernameInput.addEventListener('blur', validateUsername);
